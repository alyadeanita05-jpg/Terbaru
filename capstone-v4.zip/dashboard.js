import {
  React, h, useCtx, card, btn, btn2, Icon, Ring, Bar, Avatar, StatusBadge, DeadlineChip, Empty,
  fmtDate, deadlineLabel, daysUntil, taskProgress, courseProgress, groupProgress, userProgress,
} from './lib.js';
import { Mascot, BookStack, BookShelf, Thumb } from './art.js';
import { TaskForm } from './task.js';
import { ActivityItem, CourseForm } from './pages.js';
const { useState } = React;

const Section = ({ title, href, link, children }) => h`<section className="rounded-3xl bg-white p-4 shadow-[0_6px_24px_-14px_rgba(39,41,61,.25)] sm:p-5">
  <div className="mb-3 flex items-center justify-between"><h3 className="font-bold text-gray-900">${title}</h3>
    ${href && h`<a href=${href} className="text-sm font-medium text-[#2e5666] hover:text-[#27293d]">${link} →</a>`}</div>${children}</section>`;

const Names = ({ ids }) => { const { byId } = useCtx(); return h`<span className="flex -space-x-1.5">${ids.slice(0, 3).map((u) => h`<span key=${u} title=${byId[u]?.name} className="rounded-full ring-2 ring-white"><${Avatar} p=${byId[u]} size=${22} /></span>`)}</span>`; };
const TaskLine = ({ t, courseName, color, who }) => h`<a href=${'#/tasks/' + t.id} className="lift flex items-center gap-3 rounded-xl border border-gray-100 bg-white px-3 py-2.5">
  <span className="h-9 w-1.5 shrink-0 rounded-full" style=${{ background: color || '#27293d' }}></span>
  <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold text-gray-800">${t.title}</div><div className="truncate text-xs text-gray-400">${courseName || ''}</div></div>
  ${who && who.length > 0 && h`<span className="hidden shrink-0 sm:block"><${Names} ids=${who} /></span>`}<${StatusBadge} s=${t.status} /><${DeadlineChip} t=${t} />
  <div className=${'shrink-0 text-right text-xs ' + (t.deadline && daysUntil(t.deadline) < 0 ? 'font-semibold text-red-600' : 'text-gray-500')}>${t.deadline ? fmtDate(t.deadline) : ''}<br />${t.deadline ? deadlineLabel(t.deadline) : ''}</div></a>`;

export function Dashboard() {
  const { d, me, group, user } = useCtx();
  const [form, setForm] = useState(null);
  const open = d.tasks.filter((t) => t.status !== 'selesai');
  const done = d.tasks.length - open.length;
  const course = (id) => d.courses.find((c) => c.id === id);
  const mineIds = new Set(d.taskMembers.filter((m) => m.user_id === user.id).map((m) => m.task_id));
  const mine = open.filter((t) => mineIds.has(t.id)).sort((a, b) => (a.deadline || '9').localeCompare(b.deadline || '9')).slice(0, 5);
  const upcoming = open.filter((t) => t.deadline).sort((a, b) => a.deadline.localeCompare(b.deadline)).slice(0, 4);
  const whoOf = (id) => d.taskMembers.filter((m) => m.task_id === id).map((m) => m.user_id);
  const near = upcoming.filter((t) => daysUntil(t.deadline) <= 2);
  const active = d.courses.map((c) => ({ c, p: courseProgress(d, c.id) })).filter((x) => x.p < 100 || d.tasks.every((t) => t.course_id !== x.c.id)).slice(0, 6);
  const prog = groupProgress(d);
  const hour = new Date().getHours();
  const greet = hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 19 ? 'Selamat sore' : 'Selamat malam';
  const cntS = (s) => d.tasks.filter((t) => t.status === s).length;
  const stats = [['Total tugas', d.tasks.length, 'check', 'bg-lav-100 text-navy-600'], ['To Do', cntS('belum'), 'clock', 'bg-gray-100 text-gray-600'], ['In Progress', cntS('proses') + cntS('revisi'), 'act', 'bg-amber-100 text-amber-700'], ['Review', cntS('review'), 'rev', 'bg-cream-200 text-navy-600'], ['Done', done, 'tick', 'bg-green-100 text-green-700']];

  const memberStats = d.members.map((m) => ({ m, p: userProgress(d, m.user_id) }));
  const featured = [...mine, ...open.filter((t) => !mineIds.has(t.id))].slice(0, 6);

  const Tile = ({ t }) => { const c = course(t.course_id); const p = taskProgress(d, t.id); return h`<a href=${'#/tasks/' + t.id} className="lift group block overflow-hidden rounded-3xl bg-white p-2.5 shadow-[0_6px_24px_-14px_rgba(39,41,61,.25)]">
    <${Thumb} seed=${t.id} className="h-28 w-full" />
    <div className="px-1.5 pb-1 pt-3"><div className="mb-1 flex items-center justify-between gap-2"><span className="truncate text-[11px] font-semibold uppercase tracking-wide text-gray-400">${c?.name || 'Tanpa mata kuliah'}</span><${DeadlineChip} t=${t} /></div>
      <h4 className="line-clamp-2 min-h-[2.5rem] text-sm font-bold text-[#27293d]">${t.title}</h4>
      <div className="mt-2 flex items-center gap-2"><div className="flex-1"><${Bar} value=${p} slim /></div><span className="text-xs font-semibold text-gray-500">${p}%</span></div>
      <div className="mt-2.5 flex items-center justify-between"><${Names} ids=${whoOf(t.id)} /><${StatusBadge} s=${t.status} /></div></div></a>`; };

  return h`<div className="fade-in space-y-5">
    <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#2d3050] via-[#27293d] to-[#1f2133] p-6 text-white shadow-[0_20px_50px_-25px_rgba(39,41,61,.7)] sm:p-8">
      <span className="absolute -right-10 -top-16 h-56 w-56 rounded-full bg-[#b2d4dd]/15"></span><span className="absolute bottom-[-4rem] left-1/3 h-40 w-40 rounded-full bg-white/5"></span>
      <div className="relative flex items-center gap-4">
        <div className="hidden shrink-0 md:block"><${BookShelf} size=${130} /></div>
        <div className="min-w-0 flex-1 text-center md:text-left">
          <div className="text-xs font-medium text-[#b2d4dd]">${new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' })} · ${group.name}</div>
          <h1 className="mt-1 text-2xl font-extrabold leading-tight sm:text-3xl">${greet}, ${me.name.split(' ')[0]}!</h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-white/70 md:mx-0">${open.length === 0 ? 'Semua tugas beres. Saatnya merencanakan yang berikutnya.' : `Ada ${open.length} tugas menunggu${mine.length ? `, ${mine.length} milik Anda` : ''}. Selesaikan bersama, selangkah demi selangkah.`}</p>
          <div className="mt-4 flex flex-wrap justify-center gap-2 md:justify-start">
            <button onClick=${() => setForm('task')} className="inline-flex items-center gap-1.5 rounded-xl bg-[#b2d4dd] px-4 py-2.5 text-sm font-bold text-[#27293d] transition hover:bg-white active:scale-95"><${Icon} n="plus" size=${16} />Tambah tugas</button>
            <button onClick=${() => setForm('course')} className="inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/20 active:scale-95"><${Icon} n="folder" size=${16} />Mata kuliah baru</button></div></div>
        <div className="hidden shrink-0 lg:block"><${BookStack} size=${130} /></div></div></section>

    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">${stats.map(([l, v, ic, c]) => h`<div key=${l} className="lift rounded-3xl bg-white p-4 shadow-[0_6px_24px_-14px_rgba(39,41,61,.25)]">
      <div className=${'mb-3 flex h-10 w-10 items-center justify-center rounded-2xl ' + c}><${Icon} n=${ic} size=${18} /></div>
      <div className="text-3xl font-extrabold text-[#27293d]">${v}</div><div className="text-xs font-medium text-gray-500">${l}</div></div>`)}</div>

    ${near.length > 0 && h`<div className="rounded-2xl border border-red-100 bg-red-50 p-4 text-sm text-red-700"><b>Deadline dekat:</b>
      ${near.map((t) => h`<a key=${t.id} href=${'#/tasks/' + t.id} className="ml-2 underline">${t.title} (${deadlineLabel(t.deadline)})</a>`)}</div>`}

    ${d.courses.length === 0 && d.tasks.length === 0 ? h`<div className=${card}><${Empty} art="mascot" title="Belum ada proyek" text="Mulai dengan menambahkan mata kuliah atau proyek pertama kelompok Anda."
      action=${h`<button className=${btn} onClick=${() => setForm('course')}><${Icon} n="plus" size=${16} />Buat mata kuliah</button>`} /></div>` : h`
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
      <div className="min-w-0 space-y-5">
        <${Section} title=${mine.length ? 'Tugas saya & tim' : 'Tugas aktif'} href="#/tasks" link="Semua tugas">
          ${featured.length === 0 ? h`<${Empty} art="tasks" title="Semua beres" text="Tidak ada tugas aktif." />`
            : h`<div className="grid gap-4 sm:grid-cols-2 2xl:grid-cols-3">${featured.map((t) => h`<${Tile} key=${t.id} t=${t} />`)}</div>`}<//>
        <${Section} title="Proyek aktif" href="#/courses" link="Kelola">
          ${active.length === 0 ? h`<${Empty} art="mascot" title="Semua proyek selesai" text="Tambahkan mata kuliah baru untuk proyek berikutnya." />`
            : h`<div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">${active.map(({ c, p }) => {
              const n = d.tasks.filter((t) => t.course_id === c.id).length;
              return h`<a key=${c.id} href=${'#/courses/' + c.id} className="lift block rounded-2xl bg-[#f6f4ee] p-4">
                <div className="flex items-center gap-2"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style=${{ background: c.color || '#27293d' }}></span><div className="truncate font-semibold text-gray-900">${c.name}</div></div>
                <div className="mt-3 flex items-center gap-3"><div className="flex-1"><${Bar} value=${p} slim /></div><span className="text-xs font-semibold text-gray-600">${p}%</span></div>
                <div className="mt-2 text-xs text-gray-400">${n} tugas</div></a>`;
            })}</div>`}<//></div>

      <aside className="min-w-0 space-y-5">
        <section className="rounded-3xl bg-white p-5 shadow-[0_6px_24px_-14px_rgba(39,41,61,.25)]"><h3 className="mb-3 font-bold text-[#27293d]">Progres kelompok</h3>
          <div className="flex items-center gap-4"><${Ring} value=${prog} size=${92} /><div className="text-sm"><div className="font-bold text-[#27293d]">${done} / ${d.tasks.length} tugas</div><div className="text-xs text-gray-500">selesai</div></div></div>
          <div className="mt-4 space-y-2.5">${memberStats.map(({ m, p }) => h`<div key=${m.user_id} className="flex items-center gap-2.5"><${Avatar} p=${m.profile} size=${28} />
            <div className="min-w-0 flex-1"><div className="flex justify-between text-xs"><span className="truncate font-medium text-gray-700">${m.profile?.name}</span><span className="text-gray-400">${p}%</span></div><${Bar} value=${p} slim /></div></div>`)}</div></section>
        <${Section} title="Deadline terdekat" href="#/calendar" link="Kalender">
          ${upcoming.length === 0 ? h`<${Empty} art="calendar" title="Tidak ada deadline" />`
            : h`<div className="space-y-2">${upcoming.map((t) => h`<a key=${t.id} href=${'#/tasks/' + t.id} className="lift flex items-center gap-3 rounded-2xl bg-[#f6f4ee] px-3 py-2.5">
              <div className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-xl bg-white text-[#27293d]"><span className="text-[10px] uppercase leading-none text-gray-400">${new Date(t.deadline + 'T00:00:00').toLocaleDateString('id-ID', { month: 'short' })}</span><span className="text-sm font-extrabold leading-tight">${new Date(t.deadline + 'T00:00:00').getDate()}</span></div>
              <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold text-gray-800">${t.title}</div><div className="text-xs text-gray-400">${deadlineLabel(t.deadline)}</div></div></a>`)}</div>`}<//>
        <${Section} title="Aktivitas tim" href="#/activity" link="Semua">
          ${d.activity.length === 0 ? h`<${Empty} art="activity" title="Belum ada aktivitas" />` : h`<ul className="divide-y divide-gray-50">${d.activity.slice(0, 4).map((a) => h`<${ActivityItem} key=${a.id} a=${a} />`)}</ul>`}<//></aside></div>`}

    ${form === 'task' && h`<${TaskForm} onClose=${() => setForm(null)} />`}
    ${form === 'course' && h`<${CourseForm} onClose=${() => setForm(null)} />`}</div>`;
}
