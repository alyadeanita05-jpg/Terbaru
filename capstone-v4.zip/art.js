// Ilustrasi SVG lokal: maskot "Bobi" (buku berkacamata topi toga) dan ilustrasi empty state.
// Palet: navy #27293d, biru muda #b2d4dd, krem #f0ede5.
import { h, ART } from './lib.js';

const N = '#27293d', B = '#b2d4dd', C = '#f0ede5';

export const Mascot = ({ size = 120, className = '' }) => h`<svg width=${size} height=${size} viewBox="0 0 160 160" className=${'float ' + className} role="img" aria-label="Maskot Bobi">
  <ellipse cx="80" cy="146" rx="38" ry="6" fill=${N} opacity=".08" />
  <rect x="38" y="46" width="84" height="88" rx="22" fill=${N} />
  <rect x="47" y="55" width="66" height="70" rx="15" fill=${C} />
  <path d="M80 55v70" stroke=${B} strokeWidth="2" opacity=".6" />
  <circle cx="64" cy="86" r="5.2" fill=${N} /><circle cx="96" cy="86" r="5.2" fill=${N} />
  <circle cx="65.8" cy="84.2" r="1.7" fill="#fff" /><circle cx="97.8" cy="84.2" r="1.7" fill="#fff" />
  <ellipse cx="55" cy="98" rx="6.5" ry="4.2" fill=${B} /><ellipse cx="105" cy="98" rx="6.5" ry="4.2" fill=${B} />
  <path d="M72 97q8 8.5 16 0" stroke=${N} strokeWidth="3" strokeLinecap="round" fill="none" />
  <path d="M80 18l40 15-40 15-40-15z" fill=${N} /><path d="M56 41v10c0 5 11 9 24 9s24-4 24-9V41l-24 9z" fill=${N} />
  <path d="M120 33v18" stroke=${B} strokeWidth="3" strokeLinecap="round" /><circle cx="120" cy="54" r="4" fill=${B} />
  <circle cx="30" cy="92" r="9" fill=${B} /><circle cx="130" cy="92" r="9" fill=${B} />
  <rect x="58" y="130" width="16" height="10" rx="5" fill=${B} /><rect x="86" y="130" width="16" height="10" rx="5" fill=${B} /></svg>`;

const Frame = ({ children }) => h`<svg width="168" height="128" viewBox="0 0 168 128" className="mx-auto mb-1" aria-hidden="true">
  <ellipse cx="84" cy="116" rx="52" ry="6" fill=${N} opacity=".07" />${children}</svg>`;

const Sparkle = ({ x, y, s = 1 }) => h`<path transform=${`translate(${x} ${y}) scale(${s})`} d="M0-7C1 -2 2 -1 7 0 2 1 1 2 0 7-1 2-2 1-7 0-2-1-1-2 0-7z" fill=${B} className="twinkle" />`;

const arts = {
  tasks: () => h`<${Frame}>
    <rect x="42" y="14" width="84" height="98" rx="14" fill=${C} stroke=${N} strokeWidth="3" />
    <rect x="66" y="8" width="36" height="16" rx="8" fill=${N} />
    <rect x="56" y="38" width="12" height="12" rx="4" fill=${B} stroke=${N} strokeWidth="2.4" /><path d="M59 44l3 3 5-6" stroke=${N} strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="76" y="40" width="38" height="7" rx="3.5" fill=${N} opacity=".75" />
    <rect x="56" y="62" width="12" height="12" rx="4" fill="#fff" stroke=${N} strokeWidth="2.4" /><rect x="76" y="64" width="30" height="7" rx="3.5" fill=${N} opacity=".35" />
    <rect x="56" y="86" width="12" height="12" rx="4" fill="#fff" stroke=${N} strokeWidth="2.4" /><rect x="76" y="88" width="24" height="7" rx="3.5" fill=${N} opacity=".35" />
    <${Sparkle} x="138" y="28" s="1.3" /><${Sparkle} x="26" y="60" /><//>`,
  files: () => h`<${Frame}>
    <rect x="52" y="22" width="52" height="64" rx="7" fill="#fff" stroke=${N} strokeWidth="3" transform="rotate(-8 78 54)" />
    <rect x="62" y="16" width="52" height="64" rx="7" fill=${B} stroke=${N} strokeWidth="3" transform="rotate(6 88 48)" />
    <path d="M28 52a8 8 0 0 1 8-8h26l10 12h58a8 8 0 0 1 8 8v36a8 8 0 0 1-8 8H36a8 8 0 0 1-8-8z" fill=${N} />
    <path d="M28 70h112v26a8 8 0 0 1-8 8H36a8 8 0 0 1-8-8z" fill="#33364f" />
    <circle cx="70" cy="86" r="3" fill=${C} /><circle cx="98" cy="86" r="3" fill=${C} /><path d="M78 92q6 5 12 0" stroke=${C} strokeWidth="2.6" fill="none" strokeLinecap="round" />
    <${Sparkle} x="140" y="30" s="1.2" /><//>`,
  activity: () => h`<${Frame}>
    <rect x="26" y="28" width="116" height="72" rx="16" fill=${C} stroke=${N} strokeWidth="3" />
    <path d="M40 66h20l8-20 14 36 10-26 8 10h28" stroke=${N} strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="124" cy="66" r="5" fill=${B} stroke=${N} strokeWidth="2.4" /><${Sparkle} x="34" y="18" /><${Sparkle} x="146" y="26" s="1.2" /><//>`,
  links: () => h`<${Frame}>
    <rect x="22" y="40" width="64" height="38" rx="19" fill="none" stroke=${N} strokeWidth="9" transform="rotate(-20 54 59)" />
    <rect x="82" y="50" width="64" height="38" rx="19" fill="none" stroke=${B} strokeWidth="9" transform="rotate(-20 114 69)" />
    <path d="M70 70l28-16" stroke=${N} strokeWidth="9" strokeLinecap="round" opacity="0" /><${Sparkle} x="140" y="30" s="1.2" /><${Sparkle} x="28" y="94" /><//>`,
  notes: () => h`<${Frame}>
    <rect x="40" y="16" width="76" height="94" rx="12" fill=${C} stroke=${N} strokeWidth="3" />
    <path d="M40 34h76" stroke=${N} strokeWidth="3" /><circle cx="56" cy="25" r="3" fill=${N} /><circle cx="78" cy="25" r="3" fill=${N} /><circle cx="100" cy="25" r="3" fill=${N} />
    <rect x="54" y="46" width="48" height="6" rx="3" fill=${N} opacity=".4" /><rect x="54" y="60" width="40" height="6" rx="3" fill=${N} opacity=".4" /><rect x="54" y="74" width="30" height="6" rx="3" fill=${N} opacity=".4" />
    <path d="M118 62l16-16 10 10-16 16-12 3z" fill=${B} stroke=${N} strokeWidth="3" strokeLinejoin="round" /><${Sparkle} x="32" y="92" /><//>`,
  calendar: () => h`<${Frame}>
    <rect x="34" y="22" width="100" height="86" rx="14" fill="#fff" stroke=${N} strokeWidth="3" />
    <path d="M34 48h100V36a14 14 0 0 0-14-14H48a14 14 0 0 0-14 14z" fill=${N} /><rect x="58" y="14" width="8" height="18" rx="4" fill=${B} /><rect x="102" y="14" width="8" height="18" rx="4" fill=${B} />
    ${[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) => h`<rect key=${r + '-' + c} x=${48 + c * 22} y=${58 + r * 16} width="12" height="10" rx="3" fill=${r === 1 && c === 2 ? N : B} opacity=${r === 1 && c === 2 ? 1 : 0.55} />`))}<//>`,
  courses: () => h`<${Frame}>
    <rect x="36" y="26" width="30" height="84" rx="6" fill=${N} /><rect x="70" y="20" width="30" height="90" rx="6" fill=${B} stroke=${N} strokeWidth="3" />
    <rect x="104" y="30" width="30" height="80" rx="6" fill=${C} stroke=${N} strokeWidth="3" transform="rotate(8 119 70)" />
    <rect x="42" y="38" width="18" height="5" rx="2.5" fill=${C} /><rect x="76" y="34" width="18" height="5" rx="2.5" fill=${N} /><${Sparkle} x="140" y="22" s="1.2" /><//>`,
};

export const ART_KEYS = Object.keys(arts);
Object.entries(arts).forEach(([k, f]) => { ART[k] = f; });
ART.mascot = () => h`<${Mascot} size=${110} />`;

// ---------- ilustrasi buku bergaya 3D lembut (hero & thumbnail kartu) ----------
const Defs = ({ id }) => h`<defs>
  <linearGradient id=${id + 'n'} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#4a4e78" /><stop offset="1" stopColor="#27293d" /></linearGradient>
  <linearGradient id=${id + 'b'} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#d9edf2" /><stop offset="1" stopColor="#8fbac7" /></linearGradient>
  <linearGradient id=${id + 'c'} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffffff" /><stop offset="1" stopColor="#e4dfd2" /></linearGradient>
  <linearGradient id=${id + 'o'} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#ffc9b4" /><stop offset="1" stopColor="#f08f77" /></linearGradient>
  <linearGradient id=${id + 'y'} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fde7a8" /><stop offset="1" stopColor="#f2c05c" /></linearGradient></defs>`;

// satu buku rebah: sampul bergradasi + sisi halaman krem + kilap atas
const Book = ({ id, g, x, y, w, hgt, r = 7 }) => h`<g>
  <rect x=${x} y=${y} width=${w} height=${hgt} rx=${r} fill=${`url(#${id}${g})`} />
  <rect x=${x + 8} y=${y + hgt * 0.28} width=${w - 14} height=${hgt * 0.44} rx="3" fill=${`url(#${id}c)`} />
  <rect x=${x + 3} y=${y + 2} width=${w - 6} height="3" rx="1.5" fill="#fff" opacity=".35" /></g>`;

export const BookStack = ({ size = 150, id = 'bs' }) => h`<svg width=${size} height=${size * 0.92} viewBox="0 0 160 148" className="float" aria-hidden="true"><${Defs} id=${id} />
  <ellipse cx="80" cy="132" rx="62" ry="8" fill=${N} opacity=".12" />
  <${Book} id=${id} g="n" x="18" y="98" w="124" hgt="30" /><${Book} id=${id} g="b" x="30" y="70" w="104" hgt="27" /><${Book} id=${id} g="o" x="24" y="44" w="112" hgt="25" />
  <g fill="none" stroke="#f2c05c" strokeWidth="3.4"><circle cx="64" cy="34" r="10.5" /><circle cx="92" cy="34" r="10.5" /><path d="M74.5 33q5.5-4 7 0" strokeLinecap="round" /></g>
  <${Sparkle} x="140" y="24" s="1.3" /><${Sparkle} x="14" y="60" /></svg>`;

export const BookShelf = ({ size = 150, id = 'sh' }) => h`<svg width=${size} height=${size * 0.92} viewBox="0 0 160 148" className="float" style=${{ animationDelay: '.6s' }} aria-hidden="true"><${Defs} id=${id} />
  <ellipse cx="80" cy="136" rx="62" ry="7" fill=${N} opacity=".12" />
  <rect x="34" y="42" width="20" height="74" rx="5" fill=${`url(#${id}b)`} /><rect x="38" y="52" width="12" height="5" rx="2" fill="#fff" opacity=".7" />
  <rect x="56" y="30" width="22" height="86" rx="5" fill=${`url(#${id}n)`} /><rect x="60" y="42" width="14" height="5" rx="2" fill=${B} />
  <rect x="80" y="48" width="18" height="68" rx="5" fill=${`url(#${id}y)`} /><rect x="84" y="58" width="10" height="5" rx="2" fill="#fff" opacity=".7" />
  <g transform="rotate(14 112 116)"><rect x="104" y="40" width="20" height="76" rx="5" fill=${`url(#${id}o)`} /><rect x="108" y="52" width="12" height="5" rx="2" fill="#fff" opacity=".7" /></g>
  <rect x="18" y="114" width="124" height="14" rx="7" fill=${`url(#${id}n)`} /><rect x="22" y="116" width="116" height="3" rx="1.5" fill="#fff" opacity=".25" />
  <rect x="34" y="128" width="12" height="8" rx="3" fill=${N} /><rect x="114" y="128" width="12" height="8" rx="3" fill=${N} /><${Sparkle} x="140" y="30" s="1.2" /></svg>`;

export const OpenBook = ({ size = 110, id = 'ob' }) => h`<svg width=${size} height=${size * 0.8} viewBox="0 0 160 128" aria-hidden="true"><${Defs} id=${id} />
  <ellipse cx="80" cy="116" rx="58" ry="7" fill=${N} opacity=".12" />
  <path d="M16 40l64 10 64-10v62l-64 10-64-10z" fill=${`url(#${id}n)`} />
  <path d="M22 34q30-6 58 8v62q-28-14-58-8z" fill=${`url(#${id}c)`} /><path d="M138 34q-30-6-58 8v62q28-14 58-8z" fill="#f4f1e9" />
  <g stroke=${B} strokeWidth="3" strokeLinecap="round" opacity=".9"><path d="M34 54q16-3 32 3" /><path d="M34 68q16-3 32 3" /><path d="M94 57q16-6 32-3" /><path d="M94 71q16-6 32-3" /></g>
  <path d="M104 18l8 14-3 3-9-6z" fill=${`url(#${id}y)`} /><${Sparkle} x="30" y="22" s="1.1" /></svg>`;

export const NoteArt = ({ size = 110, id = 'nt' }) => h`<svg width=${size} height=${size * 0.8} viewBox="0 0 160 128" aria-hidden="true"><${Defs} id=${id} />
  <ellipse cx="80" cy="116" rx="52" ry="7" fill=${N} opacity=".12" />
  <rect x="38" y="16" width="70" height="92" rx="11" fill=${`url(#${id}b)`} /><rect x="46" y="24" width="54" height="76" rx="7" fill=${`url(#${id}c)`} />
  <g fill=${N} opacity=".55"><rect x="54" y="38" width="38" height="5" rx="2.5" /><rect x="54" y="52" width="30" height="5" rx="2.5" /><rect x="54" y="66" width="34" height="5" rx="2.5" /></g>
  <path d="M54 82l5 5 9-11" stroke="#22a06b" strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
  <g transform="rotate(32 118 70)"><rect x="112" y="28" width="12" height="62" rx="4" fill=${`url(#${id}o)`} /><path d="M112 90l6 14 6-14z" fill="#f6dcc2" /><rect x="112" y="28" width="12" height="9" rx="4" fill=${N} /></g></svg>`;

const THUMBS = [
  ['linear-gradient(135deg,#cfe6ec,#f0ede5)', BookStack], ['linear-gradient(135deg,#d9dcec,#f0ede5)', OpenBook],
  ['linear-gradient(135deg,#fbe1d6,#f0ede5)', NoteArt], ['linear-gradient(135deg,#d7efe5,#f0ede5)', BookShelf],
];
// kotak ilustrasi untuk kartu (dipilih tetap dari seed supaya konsisten)
export const Thumb = ({ seed = '', className = '' }) => {
  const i = [...String(seed)].reduce((a, c) => a + c.charCodeAt(0), 0) % THUMBS.length;
  const [bg, Art] = THUMBS[i];
  return h`<div className=${'thumb relative flex items-center justify-center overflow-hidden rounded-2xl ' + className} style=${{ background: bg }}>
    <span className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-white/40"></span><span className="absolute -bottom-8 -left-4 h-20 w-20 rounded-full bg-white/30"></span>
    <${Art} size=${92} id=${'t' + i + String(seed).slice(0, 4)} /></div>`;
};
