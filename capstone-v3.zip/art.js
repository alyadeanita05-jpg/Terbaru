// Ilustrasi SVG lokal: maskot "Bobi" (buku berkacamata topi toga) dan ilustrasi empty state.
// Palet: navy #27293d, biru muda #b2d4dd, krem #f0ede5.
import { h, ART } from './lib.js';

const N = '#27293d', B = '#b2d4dd', C = '#f0ede5';

export const Mascot = ({ size = 120, className = '' }) => h`<svg width=${size} height=${size} viewBox="0 0 160 160" className=${'float ' + className} role="img" aria-label="Maskot Bobi">
  <ellipse cx="80" cy="146" rx="38" ry="6" fill=${N} opacity=".08" />
  <rect x="38" y="46" width="84" height="88" rx="22" fill=${N} />
  <rect x="47" y="55" width="66" height="70" rx="15" fill=${C} />
  <path d="M80 55v70" stroke=${B} strokeWidth="2" opacity=".6" />
  <circle cx="64" cy="86" r="5.2" fill=${N} /><circle cx="96" cy="86" r="5.2" fill=${N} />
  <circle cx="65.8" cy="84.2" r="1.7" fill="#fff" /><circle cx="97.8" cy="84.2" r="1.7" fill="#fff" />
  <ellipse cx="55" cy="98" rx="6.5" ry="4.2" fill=${B} /><ellipse cx="105" cy="98" rx="6.5" ry="4.2" fill=${B} />
  <path d="M72 97q8 8.5 16 0" stroke=${N} strokeWidth="3" strokeLinecap="round" fill="none" />
  <path d="M80 18l40 15-40 15-40-15z" fill=${N} /><path d="M56 41v10c0 5 11 9 24 9s24-4 24-9V41l-24 9z" fill=${N} />
  <path d="M120 33v18" stroke=${B} strokeWidth="3" strokeLinecap="round" /><circle cx="120" cy="54" r="4" fill=${B} />
  <circle cx="30" cy="92" r="9" fill=${B} /><circle cx="130" cy="92" r="9" fill=${B} />
  <rect x="58" y="130" width="16" height="10" rx="5" fill=${B} /><rect x="86" y="130" width="16" height="10" rx="5" fill=${B} /></svg>`;

const Frame = ({ children }) => h`<svg width="168" height="128" viewBox="0 0 168 128" className="mx-auto mb-1" aria-hidden="true">
  <ellipse cx="84" cy="116" rx="52" ry="6" fill=${N} opacity=".07" />${children}</svg>`;

const Sparkle = ({ x, y, s = 1 }) => h`<path transform=${`translate(${x} ${y}) scale(${s})`} d="M0-7C1 -2 2 -1 7 0 2 1 1 2 0 7-1 2-2 1-7 0-2-1-1-2 0-7z" fill=${B} className="twinkle" />`;

const arts = {
  tasks: () => h`<${Frame}>
    <rect x="42" y="14" width="84" height="98" rx="14" fill=${C} stroke=${N} strokeWidth="3" />
    <rect x="66" y="8" width="36" height="16" rx="8" fill=${N} />
    <rect x="56" y="38" width="12" height="12" rx="4" fill=${B} stroke=${N} strokeWidth="2.4" /><path d="M59 44l3 3 5-6" stroke=${N} strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="76" y="40" width="38" height="7" rx="3.5" fill=${N} opacity=".75" />
    <rect x="56" y="62" width="12" height="12" rx="4" fill="#fff" stroke=${N} strokeWidth="2.4" /><rect x="76" y="64" width="30" height="7" rx="3.5" fill=${N} opacity=".35" />
    <rect x="56" y="86" width="12" height="12" rx="4" fill="#fff" stroke=${N} strokeWidth="2.4" /><rect x="76" y="88" width="24" height="7" rx="3.5" fill=${N} opacity=".35" />
    <${Sparkle} x="138" y="28" s="1.3" /><${Sparkle} x="26" y="60" /><//>`,
  files: () => h`<${Frame}>
    <rect x="52" y="22" width="52" height="64" rx="7" fill="#fff" stroke=${N} strokeWidth="3" transform="rotate(-8 78 54)" />
    <rect x="62" y="16" width="52" height="64" rx="7" fill=${B} stroke=${N} strokeWidth="3" transform="rotate(6 88 48)" />
    <path d="M28 52a8 8 0 0 1 8-8h26l10 12h58a8 8 0 0 1 8 8v36a8 8 0 0 1-8 8H36a8 8 0 0 1-8-8z" fill=${N} />
    <path d="M28 70h112v26a8 8 0 0 1-8 8H36a8 8 0 0 1-8-8z" fill="#33364f" />
    <circle cx="70" cy="86" r="3" fill=${C} /><circle cx="98" cy="86" r="3" fill=${C} /><path d="M78 92q6 5 12 0" stroke=${C} strokeWidth="2.6" fill="none" strokeLinecap="round" />
    <${Sparkle} x="140" y="30" s="1.2" /><//>`,
  activity: () => h`<${Frame}>
    <rect x="26" y="28" width="116" height="72" rx="16" fill=${C} stroke=${N} strokeWidth="3" />
    <path d="M40 66h20l8-20 14 36 10-26 8 10h28" stroke=${N} strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="124" cy="66" r="5" fill=${B} stroke=${N} strokeWidth="2.4" /><${Sparkle} x="34" y="18" /><${Sparkle} x="146" y="26" s="1.2" /><//>`,
  links: () => h`<${Frame}>
    <rect x="22" y="40" width="64" height="38" rx="19" fill="none" stroke=${N} strokeWidth="9" transform="rotate(-20 54 59)" />
    <rect x="82" y="50" width="64" height="38" rx="19" fill="none" stroke=${B} strokeWidth="9" transform="rotate(-20 114 69)" />
    <path d="M70 70l28-16" stroke=${N} strokeWidth="9" strokeLinecap="round" opacity="0" /><${Sparkle} x="140" y="30" s="1.2" /><${Sparkle} x="28" y="94" /><//>`,
  notes: () => h`<${Frame}>
    <rect x="40" y="16" width="76" height="94" rx="12" fill=${C} stroke=${N} strokeWidth="3" />
    <path d="M40 34h76" stroke=${N} strokeWidth="3" /><circle cx="56" cy="25" r="3" fill=${N} /><circle cx="78" cy="25" r="3" fill=${N} /><circle cx="100" cy="25" r="3" fill=${N} />
    <rect x="54" y="46" width="48" height="6" rx="3" fill=${N} opacity=".4" /><rect x="54" y="60" width="40" height="6" rx="3" fill=${N} opacity=".4" /><rect x="54" y="74" width="30" height="6" rx="3" fill=${N} opacity=".4" />
    <path d="M118 62l16-16 10 10-16 16-12 3z" fill=${B} stroke=${N} strokeWidth="3" strokeLinejoin="round" /><${Sparkle} x="32" y="92" /><//>`,
  calendar: () => h`<${Frame}>
    <rect x="34" y="22" width="100" height="86" rx="14" fill="#fff" stroke=${N} strokeWidth="3" />
    <path d="M34 48h100V36a14 14 0 0 0-14-14H48a14 14 0 0 0-14 14z" fill=${N} /><rect x="58" y="14" width="8" height="18" rx="4" fill=${B} /><rect x="102" y="14" width="8" height="18" rx="4" fill=${B} />
    ${[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) => h`<rect key=${r + '-' + c} x=${48 + c * 22} y=${58 + r * 16} width="12" height="10" rx="3" fill=${r === 1 && c === 2 ? N : B} opacity=${r === 1 && c === 2 ? 1 : 0.55} />`))}<//>`,
  courses: () => h`<${Frame}>
    <rect x="36" y="26" width="30" height="84" rx="6" fill=${N} /><rect x="70" y="20" width="30" height="90" rx="6" fill=${B} stroke=${N} strokeWidth="3" />
    <rect x="104" y="30" width="30" height="80" rx="6" fill=${C} stroke=${N} strokeWidth="3" transform="rotate(8 119 70)" />
    <rect x="42" y="38" width="18" height="5" rx="2.5" fill=${C} /><rect x="76" y="34" width="18" height="5" rx="2.5" fill=${N} /><${Sparkle} x="140" y="22" s="1.2" /><//>`,
};

export const ART_KEYS = Object.keys(arts);
Object.entries(arts).forEach(([k, f]) => { ART[k] = f; });
ART.mascot = () => h`<${Mascot} size=${110} />`;
