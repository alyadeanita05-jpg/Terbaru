// Modul lampiran: upload (drag & drop + progres), preview, unduh, kartu file.
// Dipakai di Detail Tugas (tab Lampiran) dan halaman File.
import { React, h, useCtx, sb, btn, btn2, card, inp, Icon, Modal, Avatar, Empty, toast, confirmDel, fmtDate } from './lib.js';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';
const { useState, useEffect, useRef } = React;

export const FILE_TYPES = {
  pdf: { l: 'PDF', c: '#e5484d', kind: 'pdf', mime: 'application/pdf' },
  doc: { l: 'DOC', c: '#3b82f6', kind: 'doc' }, docx: { l: 'DOCX', c: '#3b82f6', kind: 'doc' },
  xls: { l: 'XLS', c: '#16a34a', kind: 'doc' }, xlsx: { l: 'XLSX', c: '#16a34a', kind: 'doc' },
  ppt: { l: 'PPT', c: '#f97316', kind: 'doc' }, pptx: { l: 'PPTX', c: '#f97316', kind: 'doc' },
  jpg: { l: 'JPG', c: '#8b7be0', kind: 'img', mime: 'image/jpeg' }, jpeg: { l: 'JPEG', c: '#8b7be0', kind: 'img', mime: 'image/jpeg' },
  png: { l: 'PNG', c: '#8b7be0', kind: 'img', mime: 'image/png' },
  zip: { l: 'ZIP', c: '#64748b', kind: 'zip' },
};
export const ACCEPT = Object.keys(FILE_TYPES).map((e) => '.' + e).join(',');
export const MAX_BYTES = 20 * 1024 * 1024;
export const extOf = (n) => (String(n).split('.').pop() || '').toLowerCase();
export const sizeText = (b) => (b == null ? '-' : b < 1024 ? b + ' B' : b < 1048576 ? Math.round(b / 1024) + ' KB' : (b / 1048576).toFixed(1) + ' MB');
export const typeOf = (name) => FILE_TYPES[extOf(name)] || { l: (extOf(name) || 'FILE').toUpperCase().slice(0, 4), c: '#94a3b8', kind: 'other' };

export function validateFile(file) {
  if (!FILE_TYPES[extOf(file.name)]) return 'Jenis file tidak didukung. Gunakan PDF, DOC/DOCX, XLS/XLSX, PPT/PPTX, JPG, PNG, atau ZIP.';
  if (file.size === 0) return 'File kosong (0 KB).';
  if (file.size > MAX_BYTES) return 'Ukuran file maksimal 20 MB.';
  return null;
}

// Ikon file bergaya "kertas" dengan label format
export const FileIcon = ({ name, size = 44 }) => {
  const t = typeOf(name);
  return h`<svg width=${size} height=${size} viewBox="0 0 48 48" className="shrink-0 file-ico" aria-hidden="true">
    <path d="M10 5h19l10 10v26a3 3 0 0 1-3 3H10a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z" fill="#fff" stroke=${t.c} strokeWidth="2" strokeLinejoin="round" />
    <path d="M29 5v8a2 2 0 0 0 2 2h8" fill=${t.c} fillOpacity=".18" stroke=${t.c} strokeWidth="2" strokeLinejoin="round" />
    <rect x="11" y="27" width="26" height="11" rx="3" fill=${t.c} />
    <text x="24" y="35.4" textAnchor="middle" fontSize="7.6" fontWeight="800" fill="#fff" fontFamily="Plus Jakarta Sans, sans-serif">${t.l}</text></svg>`;
};

// ---------- akses file ----------
const explainStorage = (e) => {
  const m = String((e && (e.message || e.error)) || e || '');
  if (/not.?found|404|no such/i.test(m) || (e && (e.status === 404 || e.statusCode === '404'))) return 'File tidak ditemukan di penyimpanan. Kemungkinan sudah dihapus.';
  if (/jwt|expired|unauthor|401/i.test(m)) return 'Sesi Anda berakhir. Silakan keluar lalu masuk kembali.';
  if (/row-level|permission|policy|403|forbidden|not allowed/i.test(m)) return 'Anda tidak punya izin untuk mengakses file ini.';
  if (/failed to fetch|network|load failed/i.test(m)) return 'Tidak dapat terhubung ke server. Periksa koneksi internet Anda.';
  return 'Gagal memproses file: ' + (m || 'kesalahan tidak diketahui');
};

// Mengambil file lewat sesi login (sesuai izin RLS), lalu dijadikan blob lokal.
// Cara ini tidak diblokir popup-blocker dan tidak bergantung pada signed URL yang kedaluwarsa.
export async function fetchFileBlob(a) {
  const r = await sb.storage.from('attachments').download(a.file_path);
  if (r.error) throw new Error(explainStorage(r.error));
  const t = typeOf(a.file_name);
  return t.mime ? new Blob([r.data], { type: t.mime }) : r.data;
}

export async function downloadFile(a) {
  try {
    const blob = await fetchFileBlob(a);
    const url = URL.createObjectURL(blob);
    const el = document.createElement('a');
    el.href = url; el.download = a.file_name; document.body.appendChild(el); el.click(); el.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    toast('Mengunduh ' + a.file_name);
  } catch (e) { toast(e.message, 'error'); }
}

export function PreviewModal({ a, onClose }) {
  const [state, setState] = useState({ loading: true, url: null, err: '' });
  const t = typeOf(a.file_name);
  useEffect(() => {
    let alive = true; let made = null;
    (async () => {
      try {
        const blob = await fetchFileBlob(a);
        made = URL.createObjectURL(blob);
        if (alive) setState({ loading: false, url: made, err: '' });
      } catch (e) { if (alive) setState({ loading: false, url: null, err: e.message }); }
    })();
    return () => { alive = false; if (made) URL.revokeObjectURL(made); };
  }, [a.id]);
  return h`<${Modal} title=${a.file_name} onClose=${onClose} wide>
    ${state.loading && h`<div className="flex flex-col items-center gap-3 py-14 text-sm text-gray-500"><span className="spin inline-block h-7 w-7 rounded-full border-[3px] border-lav-300 border-t-navy-600"></span>Membuka file…</div>`}
    ${state.err && h`<div className="rounded-2xl bg-red-50 p-5 text-center text-sm text-red-700" role="alert">${state.err}</div>`}
    ${state.url && t.kind === 'img' && h`<img src=${state.url} alt=${a.file_name} className="mx-auto max-h-[68vh] rounded-xl object-contain pop-in" />`}
    ${state.url && t.kind === 'pdf' && h`<iframe src=${state.url} title=${a.file_name} className="h-[68vh] w-full rounded-xl border border-gray-100"></iframe>`}
    ${state.url && t.kind !== 'img' && t.kind !== 'pdf' && h`<div className="flex flex-col items-center gap-3 py-10 text-center"><${FileIcon} name=${a.file_name} size=${72} />
      <p className="max-w-sm text-sm text-gray-600">Format ${t.l} tidak bisa ditampilkan langsung di browser. Unduh file lalu buka dengan aplikasi yang sesuai.</p></div>`}
    <div className="mt-4 flex flex-wrap justify-end gap-2">
      ${state.url && t.kind === 'pdf' && h`<a href=${state.url} target="_blank" rel="noopener" className=${btn2}><${Icon} n="out" size=${15} />Buka di tab baru</a>`}
      <button className=${btn} onClick=${() => downloadFile(a)}><${Icon} n="dl" size=${15} />Download</button></div><//>`;
}

// ---------- upload dengan indikator progres ----------
function putObject(path, file, token, onProgress) {
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    const url = `${SUPABASE_URL}/storage/v1/object/attachments/${path.split('/').map(encodeURIComponent).join('/')}`;
    xhr.open('POST', url);
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.setRequestHeader('apikey', SUPABASE_ANON_KEY);
    xhr.setRequestHeader('x-upsert', 'false');
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onerror = () => resolve({ error: { message: 'failed to fetch' } });
    xhr.ontimeout = () => resolve({ error: { message: 'network timeout' } });
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve({ error: null });
      let msg = ''; try { msg = JSON.parse(xhr.responseText).message || ''; } catch { /* abaikan */ }
      resolve({ error: { message: msg || 'HTTP ' + xhr.status, status: xhr.status } });
    };
    const fd = new FormData(); fd.append('cacheControl', '3600'); fd.append('', file);
    xhr.send(fd);
  });
}

// task: objek tugas tetap (Detail Tugas) | tasks: daftar untuk dipilih (halaman File)
export function Uploader({ task, tasks }) {
  const { group, user, reload, log } = useCtx();
  const [items, setItems] = useState([]);
  const [over, setOver] = useState(false);
  const [pick, setPick] = useState('');
  const input = useRef(null);
  const busy = items.some((i) => i.status === 'up');
  const patch = (id, p) => setItems((l) => l.map((i) => (i.id === id ? { ...i, ...p } : i)));

  async function handle(fileList) {
    const files = [...fileList];
    if (!files.length) return;
    const taskId = task ? task.id : pick || null;
    const rows = files.map((f, i) => ({ id: Date.now() + '-' + i, name: f.name, size: f.size, pct: 0, status: 'wait', error: '', f }));
    setItems((l) => [...rows, ...l].slice(0, 8));
    let ok = 0;
    for (const row of rows) {
      const bad = validateFile(row.f);
      if (bad) { patch(row.id, { status: 'err', error: bad }); continue; }
      patch(row.id, { status: 'up' });
      const { data } = await sb.auth.getSession();
      const token = data && data.session && data.session.access_token;
      if (!token) { patch(row.id, { status: 'err', error: 'Sesi Anda berakhir. Silakan masuk kembali.' }); continue; }
      const path = `${group.id}/${taskId || 'umum'}/${Date.now()}-${row.f.name.replace(/[^\w.\-]/g, '_')}`;
      const up = await putObject(path, row.f, token, (p) => patch(row.id, { pct: p }));
      if (up.error) { patch(row.id, { status: 'err', error: 'Gagal mengunggah: ' + explainStorage(up.error).replace(/^Gagal memproses file: /, '') }); continue; }
      const ins = await sb.from('attachments').insert({ group_id: group.id, task_id: taskId, user_id: user.id, file_name: row.f.name, file_path: path, file_size: row.f.size, mime_type: row.f.type || null });
      if (ins.error) {
        await sb.storage.from('attachments').remove([path]);
        patch(row.id, { status: 'err', error: 'File terunggah tetapi gagal dicatat: ' + ins.error.message });
        continue;
      }
      patch(row.id, { status: 'done', pct: 100 }); ok++;
      await log(`mengunggah lampiran ${row.f.name}${task ? ' pada tugas ' + task.title : ''}`, taskId);
    }
    if (ok) { await reload(['attachments', 'activity']); toast(ok + ' file berhasil diunggah'); }
    if (input.current) input.current.value = '';
    setTimeout(() => setItems((l) => l.filter((i) => i.status !== 'done')), 2500);
  }

  return h`<div className="mb-4">
    ${tasks && h`<div className="mb-2"><select className=${inp} value=${pick} onChange=${(e) => setPick(e.target.value)} aria-label="Tugas terkait"><option value="">Tanpa tugas tertentu</option>${tasks.map((t) => h`<option key=${t.id} value=${t.id}>${t.title}</option>`)}</select></div>`}
    <div onDragOver=${(e) => { e.preventDefault(); setOver(true); }} onDragLeave=${() => setOver(false)} onDrop=${(e) => { e.preventDefault(); setOver(false); handle(e.dataTransfer.files); }}
      className=${'drop flex flex-col items-center gap-1.5 rounded-2xl border-2 border-dashed px-4 py-6 text-center transition-colors ' + (over ? 'border-navy-600 bg-lav-200 drop-on' : 'border-lav-300 bg-lav-50')}>
      <span className="float flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-navy-600 shadow-sm"><${Icon} n="up" size=${22} /></span>
      <div className="text-sm font-semibold text-gray-800">${over ? 'Lepaskan file di sini' : 'Tarik file ke sini'}</div>
      <div className="text-xs text-gray-500">PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, JPG, PNG, ZIP · maks. 20 MB</div>
      <button type="button" className=${btn + ' mt-1'} disabled=${busy} onClick=${() => input.current && input.current.click()}><${Icon} n="clip" size=${16} />${busy ? 'Mengunggah…' : 'Pilih file'}</button>
      <input ref=${input} type="file" multiple className="hidden" accept=${ACCEPT} onChange=${(e) => handle(e.target.files)} /></div>
    ${items.length > 0 && h`<ul className="mt-3 space-y-2" aria-live="polite">${items.map((i) => h`<li key=${i.id} className="rounded-xl border border-gray-100 bg-white p-3 pop-in">
      <div className="flex items-center justify-between gap-2 text-sm"><span className="truncate font-medium text-gray-800">${i.name}</span>
        <span className=${'shrink-0 text-xs font-semibold ' + (i.status === 'err' ? 'text-red-600' : i.status === 'done' ? 'text-green-600' : 'text-gray-500')}>${i.status === 'done' ? 'Selesai ✓' : i.status === 'err' ? 'Gagal' : i.status === 'wait' ? 'Menunggu' : i.pct + '%'}</span></div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-gray-100"><div className=${'h-full rounded-full transition-all duration-300 ' + (i.status === 'err' ? 'bg-red-400' : i.status === 'done' ? 'bg-green-500' : 'bg-navy-600')} style=${{ width: (i.status === 'err' ? 100 : i.pct) + '%' }}></div></div>
      ${i.error && h`<div className="mt-1.5 text-xs text-red-600" role="alert">${i.error}</div>`}</li>`)}</ul>`}</div>`;
}

// ---------- kartu & daftar ----------
export function FileCard({ a, task, onPreview, onDelete, canDelete }) {
  const { byId } = useCtx();
  const t = typeOf(a.file_name);
  return h`<article className=${card + ' lift flex flex-col gap-3 p-4'}>
    <div className="flex items-start gap-3"><${FileIcon} name=${a.file_name} />
      <div className="min-w-0 flex-1"><div className="break-words text-sm font-semibold leading-snug text-gray-900" title=${a.file_name}>${a.file_name}</div>
        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-gray-500"><span className="rounded-full bg-gray-100 px-2 py-0.5 font-semibold text-gray-600">${t.l}</span><span>${sizeText(a.file_size)}</span></div></div></div>
    <div className="flex items-center gap-2 text-xs text-gray-500"><${Avatar} p=${byId[a.user_id]} size=${20} /><span className="truncate">${byId[a.user_id]?.name || 'Anggota'}</span><span>· ${fmtDate(a.created_at.slice(0, 10))}</span></div>
    ${task && h`<a href=${'#/tasks/' + task.id} className="w-fit max-w-full truncate rounded-full bg-lav-100 px-2.5 py-0.5 text-xs font-medium text-lav-700 hover:bg-lav-200">${task.title}</a>`}
    <div className="mt-auto flex gap-2"><button className=${btn + ' flex-1 !px-3 !py-2'} onClick=${() => onPreview(a)}><${Icon} n="eye" size=${15} />Preview</button>
      <button className=${btn2 + ' flex-1 !px-3 !py-2'} onClick=${() => downloadFile(a)}><${Icon} n="dl" size=${15} />Download</button>
      ${canDelete && h`<button className="rounded-xl border border-gray-200 p-2 text-gray-400 hover:border-red-200 hover:bg-red-50 hover:text-red-600" onClick=${() => onDelete(a)} aria-label="Hapus file"><${Icon} n="trash" size=${16} /></button>`}</div></article>`;
}

export function FileGrid({ list, showTask }) {
  const { d, user, isLeader, reload, log } = useCtx();
  const [prev, setPrev] = useState(null);
  async function del(a) {
    if (!confirmDel(`Hapus file "${a.file_name}"?`)) return;
    const r = await sb.from('attachments').delete().eq('id', a.id); // izin dicek dulu (pemilik/ketua)
    if (r.error) return toast('Gagal menghapus: ' + r.error.message, 'error');
    await sb.storage.from('attachments').remove([a.file_path]);
    toast('File dihapus');
    await log(`menghapus lampiran ${a.file_name}`, a.task_id);
    reload(['attachments', 'activity']);
  }
  return h`<div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">${list.map((a) => h`<${FileCard} key=${a.id} a=${a} task=${showTask ? d.tasks.find((t) => t.id === a.task_id) : null}
    onPreview=${setPrev} onDelete=${del} canDelete=${a.user_id === user.id || isLeader} />`)}</div>
    ${prev && h`<${PreviewModal} a=${prev} onClose=${() => setPrev(null)} />`}</div>`;
}
