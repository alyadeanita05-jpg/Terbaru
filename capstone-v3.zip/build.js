// Build statis untuk Vercel: menyalin file ke dist/ dan membuat config.js dari environment variables.
const fs = require('fs'), path = require('path');
const url = (process.env.SUPABASE_URL || '').trim();
const key = (process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '').trim();
if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)) {
  console.error('ERROR: SUPABASE_URL belum diisi atau formatnya salah. Contoh: https://abcdefgh.supabase.co (tanpa / di akhir, tanpa /rest/v1).');
  process.exit(1);
}
if (!key || key.startsWith('sb_secret_') || key.includes('service_role')) {
  console.error('ERROR: SUPABASE_PUBLISHABLE_KEY kosong, atau Anda memasukkan secret/service_role key. Pakai Publishable (anon) key saja.');
  process.exit(1);
}
const cp = require('child_process'), os = require('os');
const files = ['index.html', 'app.js', 'lib.js', 'auth.js', 'pages.js', 'pages2.js', 'task.js','dashboard.js','tasks.js','work.js','resources.js','activity.js','files.js','art.js'];
// Toleran terhadap nama file yang bertambah akhiran, mis. "app br.js" atau "app (1).js" -> app.js
const present = fs.readdirSync('.');
const find = (name) => {
  if (present.includes(name)) return name;
  const ci = present.find((f) => f.toLowerCase() === name.toLowerCase()); // mis. Task.js -> task.js
  if (ci) return ci;
  const ext = path.extname(name), base = name.slice(0, -ext.length);
  return present.find((f) => f.startsWith(base) && f.endsWith(ext) && !/^[0-9a-z]/i.test(f.slice(base.length, -ext.length || undefined))) || null;
};
const src = {};
for (const f of files) {
  src[f] = find(f);
  if (!src[f]) { console.error('ERROR: file ' + f + ' tidak ditemukan di repo. File yang ada: ' + present.join(', ')); process.exit(1); }
}
for (const f of files.filter((x) => x.endsWith('.js'))) {
  const tmp = path.join(os.tmpdir(), 'chk-' + f.replace(/\.js$/, '.mjs'));
  fs.copyFileSync(src[f], tmp);
  try { cp.execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' }); }
  catch (e) { console.error('ERROR sintaks pada ' + src[f] + ':\n' + (e.stderr || e.message)); process.exit(1); }
}

// Pemeriksaan versi: pastikan setiap import ./xxx.js benar-benar ada di file tujuan.
// Kalau ada file di GitHub yang masih versi lama, build dihentikan dengan pesan jelas
// (situs yang sedang online tetap aman, tidak berubah menjadi layar putih).
{
  const text = {}, exp = {};
  for (const f of files.filter((x) => x.endsWith('.js'))) {
    text[f] = fs.readFileSync(src[f], 'utf8');
    const e = new Set();
    for (const m of text[f].matchAll(/export\s+(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z0-9_$]+)/g)) e.add(m[1]);
    for (const m of text[f].matchAll(/export\s*\{([^}]*)\}/g)) m[1].split(',').forEach((n) => { n = n.trim().split(/\s+as\s+/).pop(); if (n) e.add(n); });
    exp[f] = e;
  }
  const problems = [];
  for (const f of Object.keys(text)) {
    for (const m of text[f].matchAll(/import\s*(?:[A-Za-z0-9_$]+\s*,\s*)?\{([^}]*)\}\s*from\s*'\.\/([A-Za-z0-9_-]+\.js)'/g)) {
      const target = m[2];
      if (!exp[target]) continue; // mis. config.js dibuat saat build
      for (const raw of m[1].split(',')) {
        const n = raw.trim().split(/\s+as\s+/)[0];
        if (n && !exp[target].has(n)) problems.push(`${f} membutuhkan "${n}" dari ${target}, tetapi ${target} di GitHub belum versi terbaru.`);
      }
    }
  }
  if (problems.length) {
    console.error('ERROR: ada file yang belum versi terbaru. Unggah ulang file yang disebut ini ke GitHub (timpa yang lama):\n - ' + [...new Set(problems)].join('\n - '));
    process.exit(1);
  }
}
fs.rmSync('dist', { recursive: true, force: true });
fs.mkdirSync('dist');
for (const f of files) fs.copyFileSync(src[f], path.join('dist', f));
fs.writeFileSync('dist/config.js', `export const SUPABASE_URL = ${JSON.stringify(url)};\nexport const SUPABASE_ANON_KEY = ${JSON.stringify(key)};\n`);
console.log('Build OK -> dist/');
